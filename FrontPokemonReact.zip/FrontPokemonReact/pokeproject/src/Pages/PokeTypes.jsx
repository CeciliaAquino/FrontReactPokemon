import React from 'react'

const PokeTypes = () => {
  return (
    <div>PokeTypes</div>
  )
}

export default PokeTypes