export const routes ={
    home: '/',
    pokeList: '/pokemon',
    pokemon: '/pokemon/:name',
    pokeTypes: '/types'
}